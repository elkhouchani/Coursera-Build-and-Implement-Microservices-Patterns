const mongoose = require('mongoose');

const Mongo_URI = 'mongodb://localhost:27017/userproductdb';

exports.connect = () => {

  // Write the code to establish the database connectivity

};