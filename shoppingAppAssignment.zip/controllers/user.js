const User = require('../model/user');

const addUser = async (req, res) => {
    if (!req.body.email || !req.body.username || !req.body.password) {
        return res.status(400).json({ message: "Email, username, and password are required" });
    }

    const user = new User({
        email: req.body.email,
        username: req.body.username,
        password: req.body.password,
        productList: req.body.productList || [],
    });

    try {
        const newUser = await user.save();
        res.status(201).json(newUser);
    } catch (err) {
        res.status(409).json({ message: 'User already exists' });
    }
};

module.exports = { addUser };
