const Product = require('../model/product');

const getProducts = async (req, res) => {
    try {
        const products = await Product.find();
        res.json(products);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

const addProduct = async (req, res) => {
    const product = new Product({
        productId: req.body.productId,
        productName: req.body.productName,
        productDisc: req.body.productDisc,
        inStock: req.body.inStock,
    });

    try {
        const newProduct = await product.save();
        res.status(201).json(newProduct);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
};

const deleteProduct = async (req, res) => {
    try {
        await Product.deleteOne({ productId: req.params.id });
        res.json({ message: 'Deleted product' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

module.exports = { getProducts, addProduct, deleteProduct };
