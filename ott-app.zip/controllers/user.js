const User = require('../model/user');

const addUser = async (req, res) => {
    try {
        const { email, username, password, movieList } = req.body;
        if (!email || !username || !password) {
            return res.status(400).json({ message: 'Email, username, and password are required' });
        }
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(409).json({ message: 'User already exists' });
        }
        const newUser = new User({ email, username, password, movieList });
        await newUser.save();
        return res.status(201).json({ message: 'User created successfully' });
    } catch (error) {
        return res.status(500).json({ message: 'Error creating user', error: error.message });
    }
}

module.exports = addUser;
