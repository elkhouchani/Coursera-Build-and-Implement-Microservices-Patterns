const mongoose = require("mongoose");

// Load environment variables from .env file if using dotenv package
require('dotenv').config();

const { MONGO_URI } = process.env;

exports.connect = async () => {
    try {
        await mongoose.connect(MONGO_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        console.log("Successfully connected to movie database");
    } catch (error) {
        console.error("Database connection failed.", error);
        process.exit(1); // Exit process with failure
    }
};
