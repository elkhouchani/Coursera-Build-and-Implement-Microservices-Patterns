const express = require('express');
const router = express.Router();
const addUser = require('../controllers/user');

// Route to add user details
router.post('/', addUser);

module.exports = router;
