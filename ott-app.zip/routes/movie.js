const express = require('express');
const router = express.Router();
const { getMovies, addMovie, deleteMovie } = require('../controllers/movie');

// Route to get movie details
router.get('/:userId', getMovies);

// Route to add movie details
router.post('/:userId', addMovie);

// Route to delete movie details
router.delete('/:userId/:movieId', deleteMovie);

module.exports = router;
